#!/usr/bin/env python

# Run hadoop streaming (command):
#
# hadoop jar /usr/lib/hadoop/hadoop-streaming.jar -files inverted_index_mapper.py,inverted_index_reducer.py -mapper 'python inverted_index_mapper.py' -reducer 'python inverted_index_reducer.py' -input /data/ -output /test-data

import sys
import os
from webbrowser import get
import string

SPECIAL_CHARS = list(string.punctuation)
ENGLISH_STOP_WORDS = open('stop_words.txt', 'r').read().splitlines()
# ENGLISH_STOP_WORDS = ["a", "I", "an", "the", "and", "is", "not", "you", "me", "it", "be", "as", "with", "for", "to", "of", "or", "but", "in", "my", "your", "our", "their"]


def get_filepath():
    try:
        filepath = os.environ["mapreduce_map_input_file"]
    except KeyError:
        filepath = os.environ["map_input_file"]
    return filepath


def remove_special_chars(word):
    for char in SPECIAL_CHARS:
        word = word.replace(char, '')
    return word


def main(separator='|'):
    for line in sys.stdin:
        words = line.strip().split()
        filepath = get_filepath()
        polling_list_elem = {filepath: 1}
        for word in words:
            word = remove_special_chars(word)
            if not word.isalpha():
                continue
            if word.lower() in ENGLISH_STOP_WORDS:
                continue
            word = "__%s__" % (word.upper())
            print("%s%s%s" % (word, separator, str(polling_list_elem)))


if __name__ == "__main__":
    main()
