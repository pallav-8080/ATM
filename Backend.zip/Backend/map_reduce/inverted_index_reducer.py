#!/usr/bin/env python
"""A more advanced Reducer, using Python iterators and generators."""

from itertools import groupby
from operator import itemgetter
import sys
import ast

def read_mapper_output(file, separator):
    for line in file:
        yield line.rstrip().split(separator, 1)

def main(separator='|'):
    data = read_mapper_output(sys.stdin, separator)
    for current_word, group in groupby(data, itemgetter(0)):
        try:
            polling_list = {}
            for key, value in group:
                """ 
                key ==> word
                value ==> "{'filepath':1}"
                """
                value = ast.literal_eval(value)  # dict ==> {"filepath":1}
                filepath = list(value.keys())[0]
                count = value[filepath]
                if filepath not in polling_list.keys():
                    polling_list[filepath] = count
                else:
                    polling_list[filepath] += count

            print("%s%s%s" % (current_word, separator, str(polling_list)))
        except ValueError:
            print("Error")

if __name__ == "__main__":
    main()
