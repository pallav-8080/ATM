#!/usr/bin/env python

from itertools import groupby
from operator import itemgetter
import sys

def read_mapper_output(file, separator):
    for line in file:
        yield line.rstrip().split(separator, 1)

def main(top_n=10, separator='|'):
    data = read_mapper_output(sys.stdin, separator)
    top_n_dict = {}
    for current_word, group in groupby(data, itemgetter(0)):
        for word, count in group:
            if word not in top_n_dict.keys():
                top_n_dict[word] = int(count)
            else:
                top_n_dict[word] += int(count)

    top_n_word_list = [k for (k,v) in sorted(top_n_dict.items(), key=lambda v: v[1], reverse=True)]

    # an edge case where there aren't enough words for specified TOP_N 
    if len(top_n_word_list) < top_n:
        top_n = len(top_n_word_list)
    
    i = 0
    while (i < top_n):
        word = top_n_word_list[i]
        count = top_n_dict[top_n_word_list[i]]
        print("%s%s%s" % (word, separator, count))
        i += 1

if __name__ == "__main__":
    top_n = int(sys.argv[1])
    main(top_n)
