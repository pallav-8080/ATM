#!/usr/bin/env python
import sys
import ast 

# Run hadoop streaming (command):
# 
# hadoop jar /usr/lib/hadoop/hadoop-streaming.jar -files top_n_mapper.py,top_n_reducer.py -mapper 'python top_n_mapper.py' -reducer 'python top_n_reducer.py' -numReduceTasks 1 -input /inverted_index/ -output /top_n_output

def main(top_n=10, separator='|'):
    word_cnt_dict = {}
    for line in sys.stdin:
        index = line.strip().split(separator, 1)
        word = index[0].strip()
        try:
            polling_dict = ast.literal_eval(index[1].strip())
        except:
            continue
        
        for file, word_cnt in polling_dict.items():
            if word not in word_cnt_dict.keys():
                word_cnt_dict[word] = int(word_cnt)
            else:
                word_cnt_dict[word] += int(word_cnt)
    
    top_n_word_list = [k for (k,v) in sorted(word_cnt_dict.items(), key=lambda v: v[1], reverse=True)]
    # an edge case where there aren't enough words for specified TOP_N 
    if len(top_n_word_list) < top_n:
        top_n = len(top_n_word_list)
    
    i = 0
    while (i < top_n):
        word = top_n_word_list[i]
        count = word_cnt_dict[top_n_word_list[i]]
        print("%s%s%s" % (word, separator, count))
        i += 1

if __name__ == "__main__":
    top_n = int(sys.argv[1])
    main(top_n)
