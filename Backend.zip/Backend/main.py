from fastapi import FastAPI, Request, File, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from search import searchWordIndex
from topN import getTopN

import json
import uvicorn
from typing import List
from inverted_index import *
import os
import time


LOCAL_FILES_DIR = f"{os.getcwd()}/hadoop_files"
HDFS_INPUT_DIR = "/inverted_index_input"
HDFS_OUTPUT_DIR = "/inverted_index_output"
LOCAL_INVERTED_INDEX_DIR = f"{os.getcwd()}/inverted_index"
INVERTED_INDEX_FILENAME = "inverted_index_recent"
LOCAL_TOP_N_DIR = f"{os.getcwd()}/top_n"

app = FastAPI()

origins = ["*"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def root():
    return {"message": "Hello World"}

@app.post("/upload")
def upload(files: list[UploadFile] = File(...)):
    try:

        print("delete all files in local 'hadoop_files/' and 'inverted_index/' (since new inverted indices are being created)")
        delete_files(LOCAL_FILES_DIR)
        delete_files(LOCAL_INVERTED_INDEX_DIR)
        delete_files(LOCAL_TOP_N_DIR)
        
        print("remove hdfs input & output directory")
        delete_hdfs_dir(HDFS_INPUT_DIR)
        delete_hdfs_dir(HDFS_OUTPUT_DIR)
        
        print("store all files on local cluster")
        for file in files:
            if not store_file(file, LOCAL_FILES_DIR):
                raise Exception(f"failed to store file - '{file.filename}'")
        
        print("store files in hdfs")
        if not copy_files_to_hdfs(local_dir=LOCAL_FILES_DIR, hdfs_dir=HDFS_INPUT_DIR):
            raise Exception(f"failed to copy files from local dir to hdfs")

        print("run map reduce job to create inverted index")
        if not create_inverted_index(HDFS_INPUT_DIR, HDFS_OUTPUT_DIR):
            raise Exception("failed to run inverted index map reduce job")

        print("merge hdfs output and store in local cluster")
        if not merge_hdfs_result(local_dir=LOCAL_INVERTED_INDEX_DIR, hdfs_output_dir=HDFS_OUTPUT_DIR, filename=INVERTED_INDEX_FILENAME):
            raise Exception("failed to merge output of mapreduce job")
        
        print("remove hdfs input & output directory")
        delete_hdfs_dir(HDFS_INPUT_DIR)
        delete_hdfs_dir(HDFS_OUTPUT_DIR)
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/search")
def search(postBody: dict):

    try:
        start = time.time()
        term = postBody['term']
        res = searchWordIndex(term)
        end = time.time()
        executionTime = end - start
        print(executionTime)
        return {"results": res, "time": executionTime}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/topN")
def search(postBody: dict):
    try:
        start = time.time()
        n = postBody['N']
        print(n)
        res = getTopN(n)
        end = time.time()
        return {"data": res, "time": end-start}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)