import ast
import shutil
import subprocess

# This function untars all tar files in a directory


def untar_files_in_dir(dir):
    res = subprocess.run(
        [f"for f in {dir}/*.tar*; do tar xf \"$f\" -C {dir} && rm \"$f\"; done"], shell=True, capture_output=True, text=True)
    if res.stdout.strip() == f"{dir}/*.tar*":
        return False
    return True

# This function untars a single tar file


def untar_file(filepath, out_dir):
    res = subprocess.run(
        [f"tar -xf {filepath} -C {out_dir} && rm {filepath}"], shell=True,  capture_output=True, text=True)
    if res.returncode != 0:
        return False
    return True

# This function unzips file into specified output directory and then deleted the ZIP file


def unzip_file(filepath, out_dir):
    res = subprocess.run([f"unzip {filepath} -d {out_dir} && rm {filepath}"],
                         shell=True, capture_output=True, text=True)
    if res.returncode != 0:
        return False
    return True

# This function decompresses provided file


def decompress_file(dir, filename):
    try:
        file_ext = filename[-4:]
        filepath = f"{dir}/{filename}"
        if file_ext == ".zip":
            unzip_file(filepath, dir)

            unzipped_dir = f"{dir}/{filename[:-4]}"
            untar_files_in_dir(unzipped_dir)
        if file_ext == ".tar":
            untar_file(filepath, dir)
        return True
    except:
        return False

# This function copies file contents into the specified directory


def store_file(file, dir):
    try:
        filepath = f"{dir}/{file.filename}"
        with open(filepath, "wb") as fp:
            shutil.copyfileobj(file.file, fp)
        decompress_file(dir, file.filename)
        return True
    except:
        return False

# This function copies files from local directory to specified hdfs directory


def copy_files_to_hdfs(local_dir, hdfs_dir):
    try:
        res = subprocess.run(
            [f"hadoop fs -put {local_dir}/* {hdfs_dir}"], shell=True, capture_output=True, text=True)
        if res.returncode != 0:
            return False
        return True
    except:
        return False

# This function merges the files in hdfs dir and stores onto local cluster (ie. new_filename)


def merge_hdfs_result(local_dir, hdfs_output_dir, filename):
    try:
        res = subprocess.run(
            [f"hadoop fs -getmerge {hdfs_output_dir} {local_dir}/{filename}"], shell=True, capture_output=True, text=True)
        if res.returncode != 0:
            return False
        return True
    except:
        return False

# This function runs mapreduce job to create inverted index


def create_inverted_index(hdfs_input_dir, hdfs_output_dir):
    cmd = f"cd map_reduce && hadoop jar /usr/lib/hadoop/hadoop-streaming.jar -files inverted_index_mapper.py,inverted_index_reducer.py,stop_words.txt -mapper 'python inverted_index_mapper.py' -reducer 'python inverted_index_reducer.py' -input {hdfs_input_dir}/* -output {hdfs_output_dir} && cd .."
    res = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    if res.returncode != 0:
        return False
    return True

# This function deletes files in local directory


def delete_files(local_dir):
    local_dir = f"{local_dir}/*"
    res = subprocess.run([f"rm -r {local_dir}"],
                         shell=True, capture_output=True, text=True)

# This function deletes an hdfs directory


def delete_hdfs_dir(hdfs_dir):
    res = subprocess.run(
        [f"hadoop fs -rm -r {hdfs_dir}"], shell=True, capture_output=True, text=True)
