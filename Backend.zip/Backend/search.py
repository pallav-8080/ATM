#search.py
import ast
from collections import OrderedDict

def searchWordIndex(term:str):
    searchTerm = '__' + term.upper() + '__'
    invertedIndex = search_word_in_file("inverted_index/inverted_index_recent", searchTerm)
    filesList = {}
    if len(invertedIndex) > 0:
        for block in invertedIndex:
            parsed_block = ast.literal_eval(block)
            for file, count in parsed_block.items(): 
                if file not in filesList:
                    filesList[file]=count
                else:
                    filesList[file]+=count
    filesList = OrderedDict(sorted(filesList.items(), key=lambda item: item[1], reverse = True))
    return filesList

def search_word_in_file(file_path, search_word):
    try:
        matching_blocks = []
        with open(file_path, 'r') as file:
            for line_number, line in enumerate(file, start=1):
                if search_word in line:
                    # print(f"Found '{search_word}' in line {line_number}: {line.strip()}")
                    matching_blocks.append(line.strip().split('|')[1])
        return matching_blocks
    except FileNotFoundError:
        print(f"Error: File '{file_path}' not found.")
    except Exception as e:
        print(f"An error occurred: {str(e)}")
