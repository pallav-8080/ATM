#search.py
# import ast
import os
import subprocess

LOCAL_TOP_N_DIR = f"{os.getcwd()}/top_n"
LOCAL_FILES_DIR = f"{os.getcwd()}/hadoop_files"
HDFS_INPUT_DIR = "/inverted_index_input"
HDFS_OUTPUT_DIR = "/inverted_index_output"
INVERTED_INDEX_FILENAME = "inverted_index_recent"

def searchIfTopNExists(N:int):
    file_path = f"{LOCAL_TOP_N_DIR}/top-{N}"
    if os.path.exists(file_path):
        print(f"The file '{file_path}' exists.")
        return True
    else:
        print(f"The file '{file_path}' does not exist.")
        return False

def getTopN(N):
    top_n_file_path = f"{LOCAL_TOP_N_DIR}/top-{N}"
    if(not searchIfTopNExists(N)):
        hadoopJobRes = runTopNHadoopJob(N)
        cleanup()
        if(hadoopJobRes == 0):
            print("errr")
            return {
                "error": True,
                "msg": "Something went wrong try again!"
            }
    return returnTopN(top_n_file_path)

def runTopNHadoopJob(N):
    try:

        print("Running hadoop cmds....")

        hadoop_command = 'hadoop fs -ls /'

        print("_______Running hadoop copy....")

        hadoop_file_copy_command = 'hadoop fs -put inverted_index/ /inverted_index'
        print("h0")
        res_copy_files = subprocess.run(hadoop_file_copy_command, shell=True, capture_output=True, text=True)
        print(res_copy_files.stderr)
        if(res_copy_files.returncode == 0):
            full_path= os.path.abspath("inverted_index")
            print("_______Running hadoop mapreduce....")
            hadoop_map_reduce_command = f"cd map_reduce && hadoop jar /usr/lib/hadoop/hadoop-streaming.jar -files top_n_mapper.py,top_n_reducer.py -mapper 'python top_n_mapper.py {N}' -reducer 'python top_n_reducer.py {N}' -numReduceTasks 1 -input /inverted_index -output /top_n && cd .."
            res_map_reduce = subprocess.run(hadoop_map_reduce_command, shell=True, capture_output=True, text=True)
            print(res_map_reduce.stderr)
            
            if(res_map_reduce.returncode == 0):
                print("_______Running hadoop merge....")
                resultFileName = f"top-{N}"
                hadoop_merge_command = f"hadoop fs -getmerge /top_n top_n/{resultFileName}"
                res_hadoop_merge = subprocess.run(hadoop_merge_command, shell=True, capture_output=True, text=True)             
                if(res_hadoop_merge.returncode == 0):
                    return 1
            else:
                return 0
        else:
            return 0
    except Exception as e:
        print(f" hadoop error {str(e)}")

def returnTopN(file_path):
    try:
        topNDict = {}
        with open(file_path, 'r') as file:
            for line_number, line in enumerate(file, start=1):
                words = line.strip().split('|')
                topNDict[words[0]] = words[1]
        return topNDict
    except FileNotFoundError:
        print(f"Error: File '{file_path}' not found.")
        return {}
    except Exception as e:
        print(f"An error occurred: {str(e)}")
        return {}

def cleanup():
    try:
        print("cleanin")
        remove_copied_data="hadoop fs -rm -r /inverted_index"
        subprocess.run(remove_copied_data, shell=True, capture_output=True,text=True)
        remove_output_dir ="hadoop fs -rm -r /top_n"
        subprocess.run(remove_output_dir, shell=True, capture_output = True, text = True)
    except Exception as e:
        print("clean error")